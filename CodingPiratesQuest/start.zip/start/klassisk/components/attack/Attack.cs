using Godot;

namespace CodingPiratesQuest.components.attack;

public partial class Attack : GodotObject
{
    
}